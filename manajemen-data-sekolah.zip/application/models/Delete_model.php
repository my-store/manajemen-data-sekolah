<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delete_model extends CI_Model
{
	public function getDelete( $table, $column, $id )
	{
		return
			$this->db->
				where($column, $id)->
					delete($table);
	}
}