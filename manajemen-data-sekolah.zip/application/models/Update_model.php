<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Update_model extends CI_Model
{   
   public function getUpdate($table, $column, $id, $data)
   {
      return
         $this->db->
            where($column, $id)->
               update($table, $data);
   }
}

// RBX Family - Jagapura --- izzatalharist@gmail.com