<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Read_model extends CI_Model
{
   
   public function getOne($table, $column, $id)
   {
      return
         $this->db->
            where($column, $id)->
               get($table)->
                  row();
   }
   
   public function getAll($table)
   {
      return
         $this->db->
               get($table)->
                  result();
   }
   
   public function getSearch($table, $column, $id)
   {
      return
         $this->db->
            like($column, $id)->
               get($table)->
                  result();
   }
}

// RBX Family - Jagapura --- izzatalharist@gmail.com