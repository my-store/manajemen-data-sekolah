<nav>
	<div class="nav-logo">
		<!-- Loaded by ajax -->
	</div>
	<div class="nav-header">
		<h2>RBX Family</h2>
		<h5>Jagapura</h5>
	</div>
	<div class="nav-logout">
		<button class="logout-btn">Logout</button>
	</div>
</nav>