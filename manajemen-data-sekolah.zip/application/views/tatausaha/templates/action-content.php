<div class="action-content">
	<div id="hidden-action-id"></div>
	<div class="action-box">
		<h4 class="action-box-title">Data terpilih</h4>
		<h5 id="action-title">
			<!-- JS Load Title -->
		</h5>
		<br>
		<div id="action-buttons">
			<div onclick="getDelete()" title="Hapus" id="deleteBtn"></div>
			<div onclick="getUpdate()" title="Ubah" id="updateBtn"></div>
		</div>
		<h3 title="Batal" onclick="removeAction()" class="action-close">Batal</h3>
	</div>
</div>