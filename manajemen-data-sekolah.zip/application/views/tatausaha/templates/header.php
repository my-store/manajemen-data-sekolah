<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?= $title; ?></title>
	<script src="<?= base_url('assets/js/jquery.js'); ?>"></script>
	<link rel="stylesheet" href="<?= base_url('assets/css/admin-default.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/admin-action.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/admin-index.css'); ?>">
	<script src="<?= base_url('assets/js/admin-master-content.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-tatausaha.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-fasilitas.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-guru.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-kegiatan.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-ruanginfo.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-add-data.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-update-data.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-delete-data.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-get-data.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-action.js'); ?>"></script>
	<script src="<?= base_url('assets/js/admin-master-nav-bottom.js'); ?>"></script>
</head>

<body>
	<input type="hidden" id="base_url" value="<?= base_url(); ?>">

