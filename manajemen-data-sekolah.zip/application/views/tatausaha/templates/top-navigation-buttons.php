<div class="navigation-btns">
	<button class="tatausaha-btn">Tata Usaha</button>
	<button class="fasilitas-btn">Fasilitas</button>
	<button class="guru-btn">Daftar Guru</button>
	<button class="kegiatan-btn">Kegiatan</button>
	<button class="ruanginfo-btn">Ruang Info</button>
</div>