<div class="master-ctn">
	<div id="master">
		<div class="master-top">
			<!-- Loaded By Ajax - JS File -->
		</div>
		<div class="master-bottom">
			<!-- Loaded By Ajax - JS File -->
		</div>
	</div>
	<div class="close-master" title="Tutup"></div>
	<div class="search-master" title="Cari"></div>
	<div class="search-close" title="Tutup"></div>
	<input placeholder="Tulis data yang akan dicari" id="search-field" class="search-field" type="text">
</div>