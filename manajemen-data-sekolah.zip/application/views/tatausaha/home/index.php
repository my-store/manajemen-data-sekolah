<main>
	<div class="dashboard">
		<video autoplay controls loop>
			<source src="<?= base_url('assets/video/rbx.mp4'); ?>" type="video/mp4" />
			Browser mu ora support coy, update disit mana!
		</video>
		<br>
		<div class="bottom-nav">
			<button class="home-btn">Statis</button>
			<button class="about-btn">Tentang</button>
		</div>
		<br>
		<p>Dashboard - @RBX DevTeam 2019</p>
	</div>

	<div class="nav-bottom-ctn">
		<div class="nav-home-ctn">
			<h4>Ubah Data Statis</h4>
			<br>
			<form method="POST" id="app-form">
				<div class="form-group">
					<h5>Nama Sekolah</h5>
					<input autocomplete="off" type="text" name="sekolah">
				</div>
				<div class="form-group">
					<h5>Alamat Sekolah</h5>
					<input autocomplete="off" type="text" name="alamat">
				</div>
				<div class="form-group">
					<h5 style="text-align: center !important;">Logo Sekolah</h5>
					<input id="input-logo-sekolah" autocomplete="off" type="file" name="logo">
				</div>
				<div class="form-group">
					<button onclick="newData('app','changeStatis')" type="button"  id="save-home">Simpan</button>
				</div>
			</form>
			<div class="home-close">Kembali</div>
		</div>

		<div class="nav-about-ctn">
			<h4>Tentang Aplikasi</h4>
			<br>
			<p>Aplikasi ini dibangun menggunakan bahasa pemrograman PHP7 dan menggunakan framework Codeigniter3, desain antar-muka aplikasi ini menggunakan HTML5, CSS3 dan JQuery/ Javascript (Style dan CRUD data via ajax).</p>
			<p>Pembuat: Izzat alharis</p>
			<p>Alamat: Jagapura 03/03 Kersana Brebes Jawa tegah.</p>
			<p>Telp: 0819-0659-0037</p>
			<p>Email: izzatalharist@gmail.com</p>
			<br>
			<h6>Copyright &copy; 2019 Allrights Reserved</h6>
			<h6>RBX Family Jagapura</h6>
			<div class="about-close">Kembali</div>
		</div>
	</div>

</main>