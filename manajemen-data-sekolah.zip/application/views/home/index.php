<div class="container">

	<div class="left-side">
		<div class="visi-misi">
			<h4>Visi dan Misi</h4>
			<div>
				<h4>Visi</h4>
				<?php $no = 1;
				foreach ($visi as $vs) : ?>
					<h5><strong><?= $no++ . '.</strong> ' . $vs->visi; ?></h5>
				<?php endforeach; ?>
				<h4>Misi</h4>
				<?php $no = 1;
				foreach ($misi as $ms) : ?>
					<h5><strong><?= $no++ . '.</strong> ' . $ms->misi; ?></h5>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<main>
		<section class="main-top">
			<div class="fasilitas">
				<h4 class="fasilitasBtn">Fasilitas</h4>
			</div>
			<div class="profile-guru">
				<h4 class="profile-guruBtn">Data guru</h4>
			</div>
		</section>
		<section class="main-bottom">
			<div class="fasilitas-content">
				<div class="fasilitas-box">
					<!-- Fasilitas Data -->
					<?php foreach ($fasilitas as $fslt) : ?>
						<div class="fasilitas-card">
							<h4><?= $fslt->nama_fasilitas; ?></h4>
							<div class="card-ket">
								<h5><?= $fslt->keterangan; ?></h5>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="profileguru-content">
				<div class="big-photo-guru">
					<!-- Big Foto Guru -->
				</div>
				<div class="profileguru-box">
					<?php foreach ($guru as $g) : ?>
						<div onclick="changeBG('guru','<?= $g->foto_guru; ?>','<?= $g->nama_guru; ?>','<?= $g->no_hp; ?>','<?= $g->tmp_lahir; ?>','<?= $g->almt_guru; ?>','<?= $g->nama_instansi; ?>','<?= $g->pendidikan; ?>','<?= $g->mengajar; ?>',)" class="small-photo" style="background-image:url(<?= base_url('assets/img/foto_guru/' . $g->foto_guru); ?>);"></div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="content">
				<video autoplay controls loop>
					<source src="<?= base_url('assets/video/rbx.mp4'); ?>" type="video/mp4" />
					Browser mu ora support coy, update disit mana!
				</video>
			</div>
		</section>
	</main>

	<div class="right-side">
		<div class="jam-digital">
			<h1 id="clock"></h1>
			<h5 id="date"></h5>
		</div>
		<div class="berita-kegiatan">
			<h4>Berita Kegiatan</h4>
			<div class="berita">
				<?php foreach ($kegiatan as $kgt) : ?>
					<h4>
						<?= $kgt->nama_kegiatan; ?>
					</h4>
					<h5>
						<strong>Tanggal:
							<?= $kgt->tgl_kegiatan; ?>
						</strong>
						<br>
						<?= $kgt->keterangan; ?>
					</h5>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

</div>