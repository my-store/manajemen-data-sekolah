<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title><?= $title; ?></title>
   <script src="<?= base_url('assets/js/jquery.js'); ?>"></script>
   <link rel="stylesheet" href="<?= base_url('assets/css/home-default.css'); ?>">
   <link rel="stylesheet" href="<?= base_url('assets/css/home-index.css'); ?>">
</head>

<body>

   <input type="hidden" id="base_url" value="<?= base_url(); ?>">

   <nav>
      <div class="nav-logo"></div>
      <div class="nav-header">
         <h2>RBX Family</h2>
         <h5>Jagapura</h5>
      </div>
      <div class="nav-login">
         <button class="login-btn">Login</button>
      </div>
   </nav>

   <div class="running-text">
      <marquee behavior="scroll" direction="left">
         <?php foreach ($ruang_info as $info) : ?>
            <p><strong><?= $info->info .'</strong>  '. $info->keterangan; ?></p>
         <?php endforeach; ?>
      </marquee>
   </div>

   <div class="modalbox login-modal">
      <div class="close-modal" title="Tutup">x</div>
      <div class="box">
         <form>
            <h3>Masuk Sebagai Admin</h3>
            <div class="form-group">
               <label>Username</label>
               <input id="username" autocomplete="off" type="text" name="username" placeholder="">
            </div>
            <div class="form-group">
               <label>Password</label>
               <input id="password" autocomplete="off" type="password" name="password" placeholder="">
            </div>
            <div class="form-group">
               <button id="getLog-btn" type="button">Masuk</button>
            </div>
            <br>
            <div class="form-group">
               <h5>Lupa password? <a href="#">Reset</a></h5>
               <br>
               <h6>Copyright &copy; 2019 Allrights Reserved</h6>
               <h6>RBX Family 2019</h6>
            </div>
         </form>
      </div>
   </div>