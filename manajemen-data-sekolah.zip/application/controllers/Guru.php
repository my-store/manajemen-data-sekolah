<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guru extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
		if( !isset($this->session->admin_log) )
		{
			redirect( base_url() );
			exit;
		}
      $this->load->model('Read_model');
      $this->load->model('Create_model');
      $this->load->model('Delete_model');
      $this->load->model('Update_model');
	}

	public function getField()
	{
		$row = $this->Read_model->getAll('guru');
		echo count($row);
	}

	public function getData()
	{
		$data['guru'] = $this->Read_model->getAll('guru');
		echo '
		<h4 class="master-bottom-title">
			<strong class="nama-guru">Nama Guru</strong>
			<strong class="tlp-guru">No tlp</strong>
			<strong class="tmp-guru">Tmp lahir</strong>
			<strong class="tgl-guru">Tgl lahir</strong>
			<strong class="almt-guru">Alamat</strong>
			<strong class="instansi-guru">Instansi</strong>
			<strong class="pendidikan-guru">Pendidikan</strong>
			<strong class="mengajar-guru">Mengajar</strong>
		</h4>
		<div class="bottom-table">
		';
		$no = 1;
		foreach($data['guru'] as $guru)
		{
			echo '
				<h5 onclick="getAct(`Guru`,`'.$guru->id_guru.'`,`'.$guru->nama_guru.'`)">'. $no++ .'.
					<strong class="nama-guru">'. $guru->nama_guru .'</strong>
					<strong class="tlp-guru">'. $guru->no_hp .'</strong>
					<strong class="tmp-guru">'. $guru->tmp_lahir .'</strong>
					<strong class="tgl-guru">'. $guru->tgl_lahir .'</strong>
					<strong class="almt-guru">'. $guru->almt_guru .'</strong>
					<strong class="instansi-guru">'. $guru->nama_instansi .'</strong>
					<strong class="pendidikan-guru">'. $guru->pendidikan .'</strong>
					<strong class="mengajar-guru">'. $guru->mengajar .'</strong>
					<div class="photo_guru_hover" style="background-image:url('.base_url('assets/img/foto_guru/'.$guru->foto_guru).');"></div>
				</h5>
			';
		}

		if( count($data['guru']) < 1 )
			echo '<h5>Tabel Guru masih kosong.</h5>';

		echo '</div>';
      exit;
	}

   public function newGuru()
   {
		$data = [
		   'nama_guru' => htmlspecialchars($_POST['nama_guru']),
		   'nama_instansi' => htmlspecialchars($_POST['nama_instansi']),
		   'no_hp' => htmlspecialchars($_POST['no_hp']),
		   'pendidikan' => htmlspecialchars($_POST['pendidikan']),
		   'tmp_lahir' => htmlspecialchars($_POST['tmp_lahir']),
		   'mengajar' => htmlspecialchars($_POST['mengajar']),
		   'almt_guru' => htmlspecialchars($_POST['almt_guru']),
			'tgl_lahir' => htmlspecialchars($_POST['tgl_lahir'])
		];
		
      if(empty(
			$data['nama_guru'] &&
			$data['nama_instansi'] &&
			$data['no_hp'] &&
			$data['pendidikan'] &&
			$data['tmp_lahir'] &&
			$data['mengajar'] &&
			$data['almt_guru'] &&
			$data['tgl_lahir']
		)) { echo 'Data harus lengkap!'; exit; }
		
		if(empty($_FILES['foto_guru']['name']))
		{
			echo 'Silahkan upload foto guru!';
			exit;
		}
		else {
			$path = 'C:/xampp/htdocs/rombax/assets/img/foto_guru/'; // Path to save file
			$filename = $_FILES["foto_guru"]["name"];
			$ext = strtolower(substr(strrchr($filename, '.'), 1)); //Get extension
			$image_name = str_replace(' ', '_', $data['nama_guru']) . '.' . $ext; //New image name
			$try = move_uploaded_file($_FILES['foto_guru']['tmp_name'], $path.$image_name); // Uploading
			if(!$try) { echo 'Gagal mengupload foto!'; exit; }
			$data['foto_guru'] = $image_name; // Image name to save in database
		}

      $try = $this->Create_model->getCreate('guru', $data);
		if(!$try) { echo 'Gagal menambahkan data!'; exit; }
		echo 'Data berhasil ditambahkan!';
      exit;
   }

   public function deleteGuru()
   {
		$id = $_GET['id'];
		$get = $this->Read_model->getOne('guru', 'id_guru', $id);
		if(!empty($get->foto_guru))
		{
			$foto = $get->foto_guru;
			$path = 'C:/xampp/htdocs/rombax/assets/img/foto_guru/';
			unlink($path . $foto);
		}
      $try = $this->Delete_model->getDelete('guru', 'id_guru', $id);
		if(!$try) { echo 'Gagal menghapus data!'; exit; }
		echo 'Data berhasil dihapus!';
      exit;
	}
	
	public function updateGuru()
	{
		$id = $_GET['id'];
		$get = $this->Read_model->getOne('guru','id_guru',$id);
		$elm = '<h3>Tabel Guru <label>Total data: <strong id="row-field"></strong><label></h3>
		<form method="POST" id="guru-form" enctype="multipart/form-data">
			<div class="form-group">
				<label>Nama guru</label>
				<input name="id_guru" type="hidden" value="'.$get->id_guru.'">
				<input name="nama_guru" type="text" value="'.$get->nama_guru.'">
				<label>Nama Instansi</label>
				<input name="nama_instansi" type="text" value="'.$get->nama_instansi.'">
				<label>Foto guru</label>
				<input title="Unggah Foto" id="foto-guru" name="foto_guru" type="file">
			</div>
			<div class="form-group">
				<label>Nomor telp</label>
				<input name="no_hp" type="text" value="'.$get->no_hp.'">
				<label>Pendidikan</label>
				<input name="pendidikan" type="text" value="'.$get->pendidikan.'">
				<div class="form-button">
					<button onclick="newData(`guru`,`getUpdateGuru`)" type="button">Simpan</button>
					<div class="btn-spacer"></div>
					<button onclick="removeField()" type="button">Batal</button>
				</div>
			</div>
			<div class="form-group">
				<label>Tempat kelahiran</label>
				<input name="tmp_lahir" type="text" value="'.$get->tmp_lahir.'">
				<label>Mengajar</label>
				<input name="mengajar" type="text" value="'.$get->mengajar.'">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<input name="almt_guru" type="text" value="'.$get->almt_guru.'">
				<label>Tgl lahir</label>
				<input name="tgl_lahir" type="text" value="'.$get->tgl_lahir.'">
			</div>
		</form>';
		echo $elm;
      exit;
	}

	public function getUpdateGuru()
	{
		$data = [
		   'nama_guru' => htmlspecialchars($_POST['nama_guru']),
		   'nama_instansi' => htmlspecialchars($_POST['nama_instansi']),
		   'no_hp' => htmlspecialchars($_POST['no_hp']),
		   'pendidikan' => htmlspecialchars($_POST['pendidikan']),
		   'tmp_lahir' => htmlspecialchars($_POST['tmp_lahir']),
		   'mengajar' => htmlspecialchars($_POST['mengajar']),
		   'almt_guru' => htmlspecialchars($_POST['almt_guru']),
			'tgl_lahir' => htmlspecialchars($_POST['tgl_lahir']),
			'id_guru' => htmlspecialchars($_POST['id_guru'])
		];
		
      if(empty(
			$data['nama_guru'] &&
			$data['nama_instansi'] &&
			$data['no_hp'] &&
			$data['pendidikan'] &&
			$data['tmp_lahir'] &&
			$data['mengajar'] &&
			$data['almt_guru'] &&
			$data['tgl_lahir']
		)) { echo 'Data harus lengkap!'; exit; }

		$get = $this->Read_model->getOne('guru','id_guru',$data['id_guru']);
		if(empty($_FILES['foto_guru']['name']))
		{
			$data['foto_guru'] = $get->foto_guru;
		}
		else {
			$path = 'C:/xampp/htdocs/rombax/assets/img/foto_guru/'; // Path to save file
			$try = unlink($path.$get->foto_guru); // Remove old photo
			if(!$try) { echo 'Gagal menghapus foto!'; exit; }
			$filename = $_FILES["foto_guru"]["name"];
			$ext = strtolower(substr(strrchr($filename, '.'), 1)); //Get extension
			$image_name = str_replace(' ', '_', $data['nama_guru']) . '.' . $ext; //New image name
			$try = move_uploaded_file($_FILES['foto_guru']['tmp_name'], $path.$image_name); // Uploading
			if(!$try) { echo 'Gagal mengupload foto!'; exit; }
			$data['foto_guru'] = $image_name; // Image name to save in database
		}
		$try = $this->Update_model->getUpdate('guru','id_guru',$data['id_guru'], $data);
		if(!$try) { echo 'Gagal merubah data!'; exit; }
		echo 'Data berhasil diubah!';
      exit;
	}

	public function getSearch()
	{
		$key = $_GET['key'];
		$data['guru'] = $this->Read_model->getSearch('guru', 'nama_guru', $key);

		$no = 1;
		foreach($data['guru'] as $guru)
		{
			echo '
				<h5 onclick="getAct(`Guru`,`'.$guru->id_guru.'`,`'.$guru->nama_guru.'`)">'. $no++ .'.
					<strong class="nama-guru">'. $guru->nama_guru .'</strong>
					<strong class="tlp-guru">'. $guru->no_hp .'</strong>
					<strong class="tmp-guru">'. $guru->tmp_lahir .'</strong>
					<strong class="tgl-guru">'. $guru->tgl_lahir .'</strong>
					<strong class="almt-guru">'. $guru->almt_guru .'</strong>
					<strong class="instansi-guru">'. $guru->nama_instansi .'</strong>
					<strong class="pendidikan-guru">'. $guru->pendidikan .'</strong>
					<strong class="mengajar-guru">'. $guru->mengajar .'</strong>
					<div class="photo_guru_hover" style="background-image:url('.base_url('assets/img/foto_guru/'.$guru->foto_guru).');"></div>
				</h5>
			';
		}

		if( count($data['guru']) < 1 )
			echo '<h5>Data tidak ditemukan.</h5>';
      exit;
	}
}