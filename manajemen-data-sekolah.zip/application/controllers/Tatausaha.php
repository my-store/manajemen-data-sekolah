<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tatausaha extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
		if( !isset($this->session->admin_log) )
		{
			redirect( base_url() );
			exit;
      }
      echo $this->session->admin_flash;
      $this->load->model('Read_model');
      $this->load->model('Create_model');
      $this->load->model('Delete_model');
      $this->load->model('Update_model');
   }

	public function getField()
	{
		$row = $this->Read_model->getAll('tata_usaha');
		echo count($row);
	}
   
   public function index()
   {
      $data = [
         'title' => 'Dashboard'
      ];
      $this->load->view('tatausaha/templates/header',$data);
      $this->load->view('tatausaha/templates/nav');
      $this->load->view('tatausaha/templates/top-navigation-buttons');
      $this->load->view('tatausaha/templates/master-content');
      $this->load->view('tatausaha/templates/action-content');
      $this->load->view('tatausaha/home/index');
      $this->load->view('tatausaha/templates/footer');
   }

   public function getData()
   {
      $data['tatausaha'] = $this->Read_model->getAll('tata_usaha');
      echo '
      <h4 class="master-bottom-title">
         <strong class="username">Username</strong>
         <strong class="password">Password</strong>
      </h4>
      <div class="bottom-table">
      ';
      $no = 1;
      foreach($data['tatausaha'] as $tatausaha)
      {
         echo '
            <h5 onclick="getAct(`Tatausaha`,`'.$tatausaha->id.'`,`'.$tatausaha->username.'`)">'. $no++ .'.
               <strong class="username">'. $tatausaha->username .'</strong>
               <strong class="password">'. $tatausaha->password .'</strong>
            </h5>
         ';
      }
		if( count($data['tatausaha']) < 1 )
			echo '<h5>Tabel Tatausaha masih kosong.</h5>';
      echo '</div>';
      exit;
   }

   public function newTatausaha()
   {
      $data = [
         'username' => htmlspecialchars($_POST['username']),
         'password' => htmlspecialchars($_POST['password'])
      ];
      if(empty(
         $data['username'] && $data['password']
      )) { echo 'Data harus lengkap!'; exit; }
      $try = $this->Read_model->getOne('tata_usaha', 'username', $data['username']);
      if( $try )
      {
         echo 'Username ini telah digunakan!';
         exit;
      }
      $try = $this->Create_model->getCreate('tata_usaha', $data);
      if(! $try) { echo 'Gagal menambahkan data!'; exit; }
      echo 'Data berhasil ditambahkan!';
      exit;
   }

   public function deleteTatausaha()
   {
      if( count($this->Read_model->getAll('tata_usaha')) > 0 )
      {
         $get = $this->Read_model->getOne('tata_usaha', 'id', $_GET['id']);
         if( $get->username === 'izzat')
         {
            echo 'Akun ini tidak dapat dihapus!';
            exit;
         }
         $try = $this->Delete_model->getDelete('tata_usaha', 'id', $_GET['id']);
         if(!$try) { echo 'Gagal menghapus data!'; exit; }
         echo 'Data berhasil dihapus!';
         exit;
      } else {
         echo 'Minimal 1 akun sebagai pengelola tata usaha, gagal menghapus data!';
         exit;
      }
   }
	
	public function updateTatausaha()
	{
      $id = $_GET['id'];
      $get = $this->Read_model->getOne('tata_usaha','id',$id);
      $elm = '<h3>Tabel Tata Usaha <label>Total data: <strong id="row-field"></strong></label></h3>
         <form method="POST" id="tatausaha-form">
            <input type="hidden" name="id" value="'.$get->id.'">
            <div class="form-group">
               <label>Username</label>
               <input type="text" name="username" value="'.$get->username.'">
               <div class="form-button">
                  <button onclick="newData(`tatausaha`,`getUpdateTatausaha`)" type="button">Simpan</button>
                  <div class="btn-spacer"></div>
                  <button onclick="removeField()" type="button">Batal</button>
               </div>
            </div>
            <div class="form-group">
               <label>Password</label>
               <input type="text" name="password" value="'.$get->password.'">
            </div>
         </form>';
      echo $elm;
      exit;
   }

   public function getUpdateTatausaha()
   {
      $data = [
         'username' => htmlspecialchars($_POST['username']),
         'password' => htmlspecialchars($_POST['password']),
         'id' => htmlspecialchars($_POST['id'])
      ];

      if(empty(
         $data['username'] && $data['password']
      )) { echo 'Data harus lengkap!'; exit; }
      if($data['id'] === '1') { echo 'Akun ini tidak dapat dirubah!'; exit; }
      $try = $this->Update_model->getUpdate('tata_usaha', 'id', $data['id'], $data);
      if(! $try) { echo 'Gagal merubah data!'; exit; }
      echo 'Data berhasil diubah!';
      exit;
   }

   public function getSearch()
   {
      $key = $_GET['key'];
      $data['tatausaha'] = $this->Read_model->getSearch('tata_usaha', 'username', $key);
      $no = 1;
      foreach($data['tatausaha'] as $tatausaha)
      {
         echo '
            <h5 onclick="getAct(`Tatausaha`,`'.$tatausaha->id.'`,`'.$tatausaha->username.'`)">'. $no++ .'.
               <strong class="username">'. $tatausaha->username .'</strong>
               <strong class="password">'. $tatausaha->password .'</strong>
            </h5>
         ';
      }
		if( count($data['tatausaha']) < 1 )
			echo '<h5>Data tidak ditemukan.</h5>';
      exit;
   }
}
