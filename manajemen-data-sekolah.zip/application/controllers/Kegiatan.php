<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
		if( !isset($this->session->admin_log) )
		{
			redirect( base_url() );
			exit;
		}
      $this->load->model('Read_model');
      $this->load->model('Create_model');
      $this->load->model('Delete_model');
      $this->load->model('Update_model');
	}

	public function getField()
	{
		$row = $this->Read_model->getAll('kegiatan');
		echo count($row);
	}

	public function getData()
	{
		$data['kegiatan'] = $this->Read_model->getAll('kegiatan');
		echo '
		<h4 class="master-bottom-title">
			<strong class="nama-kegiatan">Nama Kegiatan</strong>
			<strong class="tgl-kegiatan">Tgl Kegiatan</strong>
			<strong class="waktu-kegiatan">Waktu Kegiatan</strong>
			<strong class="ket-kegiatan">Keterangan</strong>
		</h4>
		<div class="bottom-table">
		';
		$no = 1;
		foreach($data['kegiatan'] as $kegiatan)
		{
			echo '
				<h5 onclick="getAct(`Kegiatan`,`'.$kegiatan->id_kegiatan.'`,`'.$kegiatan->nama_kegiatan.'`)">'. $no++ .'.
					<strong class="nama-kegiatan">'. $kegiatan->nama_kegiatan .'</strong>
					<strong class="tgl-kegiatan">'. $kegiatan->tgl_kegiatan .'</strong>
					<strong class="waktu-kegiatan">'. $kegiatan->waktu .'</strong>
					<strong class="ket-kegiatan">'. $kegiatan->keterangan .'</strong>
				</h5>
			';
		}
		if( count($data['kegiatan']) < 1 )
			echo '<h5>Tabel Kegiatan masih kosong.</h5>';
		echo '</div>';
      exit;
	}

   public function newKegiatan()
   {
      $data = [
         'nama_kegiatan' => htmlspecialchars($_POST['nama_kegiatan']),
         'waktu' => htmlspecialchars($_POST['waktu']),
         'tgl_kegiatan' => htmlspecialchars($_POST['tgl_kegiatan']),
         'keterangan' => htmlspecialchars($_POST['keterangan'])
      ];

      if(empty(
			$data['nama_kegiatan'] &&
			$data['waktu'] &&
			$data['tgl_kegiatan'] &&
			$data['keterangan']
      )) { echo 'Data harus lengkap!'; exit; }

      $try = $this->Create_model->getCreate('kegiatan', $data);
		if(!$try) { echo 'Gagal menambahkan data!'; exit; }
		echo 'Data berhasil ditambahkan!';
      exit;
   }

   public function deleteKegiatan()
   {
		$try = $this->Delete_model->getDelete('kegiatan', 'id_kegiatan', $_GET['id']);
		if(!$try) { echo 'Gagal menghapus data!'; exit; }
		echo 'Data berhasil dihapus!';
      exit;
   }
	
	public function updateKegiatan()
	{
		$id = $_GET['id'];
		$get = $this->Read_model->getOne('kegiatan','id_kegiatan',$id);
		$elm = '<h3>Tabel Kegiatan <label>Total data: <strong id="row-field"></strong></label></h3>
			<form method="POST" id="kegiatan-form">
				<input type="hidden" name="id_kegiatan" value="'.$get->id_kegiatan.'">
				<div class="form-group">
					<label>Nama Kegiatan</label>
					<input type="text" name="nama_kegiatan" value="'.$get->nama_kegiatan.'">
					<label>Waktu Kegiatan</label>
					<input type="text" name="waktu" value="'.$get->waktu.'">
					<div class="form-button">
						<button onclick="newData(`kegiatan`,`getUpdateKegiatan`)" type="button">Simpan</button>
						<div class="btn-spacer"></div>
						<button onclick="removeField()" type="button">Batal</button>
					</div>
				</div>
				<div class="form-group">
					<label>Tanggal Kegiatan</label>
					<input type="text" name="tgl_kegiatan" value="'.$get->tgl_kegiatan.'">
					<label>Keterangan</label>
					<input type="text" name="keterangan" value="'.$get->keterangan.'">
				</div>
			</form>';
		echo $elm;
      exit;
	}

	public function getUpdateKegiatan()
	{
      $data = [
         'nama_kegiatan' => htmlspecialchars($_POST['nama_kegiatan']),
         'waktu' => htmlspecialchars($_POST['waktu']),
         'tgl_kegiatan' => htmlspecialchars($_POST['tgl_kegiatan']),
         'keterangan' => htmlspecialchars($_POST['keterangan']),
         'id_kegiatan' => htmlspecialchars($_POST['id_kegiatan'])
      ];

      if(empty(
			$data['nama_kegiatan'] &&
			$data['waktu'] &&
			$data['tgl_kegiatan'] &&
			$data['keterangan']
		)) { echo 'Data harus lengkap!'; exit; }
		
		$try = $this->Update_model->getUpdate('kegiatan', 'id_kegiatan', $data['id_kegiatan'], $data);

		if(!$try) { echo 'Gagal merubah data!'; exit; }
		echo 'Data berhasil diubah!';
      exit;
	}

	public function getSearch()
	{
		$key = $_GET['key'];
		$data['kegiatan'] = $this->Read_model->getSearch('kegiatan', 'nama_kegiatan', $key);
		$no = 1;
		foreach($data['kegiatan'] as $kegiatan)
		{
			echo '
				<h5 onclick="getAct(`Kegiatan`,`'.$kegiatan->id_kegiatan.'`,`'.$kegiatan->nama_kegiatan.'`)">'. $no++ .'.
					<strong class="nama-kegiatan">'. $kegiatan->nama_kegiatan .'</strong>
					<strong class="tgl-kegiatan">'. $kegiatan->tgl_kegiatan .'</strong>
					<strong class="waktu-kegiatan">'. $kegiatan->waktu .'</strong>
					<strong class="ket-kegiatan">'. $kegiatan->keterangan .'</strong>
				</h5>
			';
		}
		if( count($data['kegiatan']) < 1 )
			echo '<h5>Data tidak ditemukan.</h5>';
		exit;
	}
}