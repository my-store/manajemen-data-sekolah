<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fasilitas extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
		if( !isset($this->session->admin_log) )
		{
			redirect( base_url() );
			exit;
		}
      $this->load->model('Read_model');
      $this->load->model('Create_model');
      $this->load->model('Delete_model');
      $this->load->model('Update_model');
	}

	public function getField()
	{
		$row = $this->Read_model->getAll('fasilitas');
		echo count($row);
	}
	
	public function getData()
	{		
		$data['fasilitas'] = $this->Read_model->getAll('fasilitas');
		echo '
		<h4 class="master-bottom-title">
			<strong class="nama-fasilitas">Nama Fasilitas</strong>
			<strong class="ktr-fasilitas">Keterangan</strong>
		</h4>
		<div class="bottom-table">
		';

		$no = 1;

		foreach($data['fasilitas'] as $fasilitas)
		{
			echo '
				<h5 onclick="getAct(`Fasilitas`,`'.$fasilitas->id_fasilitas.'`,`'.$fasilitas->nama_fasilitas.'`)">'. $no++ .'.
					<strong class="nama-fasilitas">'. $fasilitas->nama_fasilitas .'</strong>
					<strong class="ktr-fasilitas">'. $fasilitas->keterangan .'</strong>
				</h5>
			';
		}

		if( count($data['fasilitas']) < 1 )
			echo '<h5>Tabel Fasilitas masih kosong.</h5>';

		echo '</div>';
      exit;
	}

   public function newFasilitas()
   {
      $data = [
		   'nama_fasilitas' => htmlspecialchars($_POST['nama_fasilitas']),
		   'keterangan' => htmlspecialchars($_POST['keterangan'])
      ];
		
      if(empty(
			$data['nama_fasilitas'] && $data['keterangan']
      )) { echo 'Data harus lengkap!'; exit; }

		$try = $this->Create_model->getCreate('fasilitas', $data);
		if(!$try) { echo 'Gagal menambahkan data!'; exit; }
		echo 'Data berhasil ditambahkan!';
      exit;
	}

   public function deleteFasilitas()
   {
		$try = $this->Delete_model->getDelete('fasilitas', 'id_fasilitas', $_GET['id']);
		if(!$try) { echo 'Gagal menghapus data!'; exit; }
		echo 'Data berhasil dihapus!';
      exit;
   }
	
	public function updateFasilitas()
	{
		$id = $_GET['id'];
		$get = $this->Read_model->getOne('fasilitas','id_fasilitas',$id);
		$elm = '<h3>Tabel Fasilitas <label>Total data: <strong id="row-field"></strong></label></h3>
			<form method="POST" id="fasilitas-form">
				<input type="hidden" name="id_fasilitas" value="'.$get->id_fasilitas.'">
				<div class="form-group">
					<label>Nama Fasilitas</label>
					<input type="text" name="nama_fasilitas" value="'.$get->nama_fasilitas.'">
					<div class="form-button">
						<button onclick="newData(`fasilitas`,`getUpdateFasilitas`)" type="button">Simpan</button>
						<div class="btn-spacer"></div>
						<button onclick="removeField()" type="button">Batal</button>
					</div>
				</div>
				<div class="form-group">
					<label>Keterangan</label>
					<input type="text" name="keterangan" value="'.$get->keterangan.'">
				</div>
			</form>';
		echo $elm;
      exit;
	}

	public function getUpdateFasilitas()
	{
		$data = [
		   'nama_fasilitas' => htmlspecialchars($_POST['nama_fasilitas']),
		   'keterangan' => htmlspecialchars($_POST['keterangan']),
		   'id_fasilitas' => htmlspecialchars($_POST['id_fasilitas'])
		];
      if(empty(
			$data['nama_fasilitas'] && $data['keterangan']
      )) { echo 'Data harus lengkap!'; exit; }
		$try = $this->Update_model->getUpdate('fasilitas','id_fasilitas',$data['id_fasilitas'], $data);
		if(!$try) { echo 'Gagal merubah data!'; exit; }
		echo 'Data berhasil diubah!';
      exit;
	}

	public function getSearch()
	{
		$key = $_GET['key'];
		$data['fasilitas'] = $this->Read_model->getSearch('fasilitas', 'nama_fasilitas', $key);
		$no = 1;
		foreach($data['fasilitas'] as $fasilitas)
		{
			echo '
				<h5 onclick="getAct(`Fasilitas`,`'.$fasilitas->id_fasilitas.'`,`'.$fasilitas->nama_fasilitas.'`)">'. $no++ .'.
					<strong class="nama-fasilitas">'. $fasilitas->nama_fasilitas .'</strong>
					<strong class="ktr-fasilitas">'. $fasilitas->keterangan .'</strong>
				</h5>
			';
		}

		if( count($data['fasilitas']) < 1 )
			echo '<h5>Data tidak ditemukan.</h5>';
		exit;
	}
}