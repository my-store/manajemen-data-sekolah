<?php

class App extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
      $this->load->model('Read_model');
		$this->load->model('Update_model');
	}

	public function getData()
	{
		$statis = $this->Read_model->getOne('statis', 'app_id', '1');
		if( !$statis )
		{
			echo '<h4 style="color:yellow;">Data tidak ditemukan.</h4>';
			exit;
		}
		echo '
			<h2>'. $statis->sekolah .'</h2>
			<h5>'. $statis->alamat .'</h5>
		';
      exit;
	}

	public function getLogo()
	{
		$statis = $this->Read_model->getOne('statis', 'app_id', '1');
		if( !$statis )
		{
			echo '0';
			exit;
		}
		echo '<div class="logo" style="background-image: url('.base_url('assets/img/rbx-family/'.$statis->logo).');"></div>';
	}

   public function changeStatis()
   {
      $data = [
         'sekolah' => htmlspecialchars($_POST['sekolah']),
         'alamat' => htmlspecialchars($_POST['alamat'])
		];
		$get = $this->Read_model->getOne('statis', 'app_id', '1');
		if(!$get) { echo 'Anda telah menghapus data
		di table `statis` tanpa izin, 
		aplikasi ini tidak akan berjalan dengan baik!'; exit; }
		if(empty($data['sekolah']||$data['alamat']||$_FILES['logo']['name']) )
		{
			echo 'Silahkan pilih dan masukan data yang akan diubah!';
			exit;
		}
		else {
			if( empty($data['sekolah']) ) $data['sekolah'] = $get->sekolah;
			if( empty($data['alamat']) ) $data['alamat'] = $get->alamat;
			if( empty($_FILES['logo']['name']))
			{
				$data['logo'] = $get->logo;
			}
			else {
				$path = 'C:/xampp/htdocs/rombax/assets/img/rbx-family/'; // Path to save file
				$try = unlink($path.$get->logo); // Remove old photo
				if(!$try) { echo 'Gagal menghapus foto!'; exit; }
				$filename = $_FILES["logo"]["name"];
				$ext = strtolower(substr(strrchr($filename, '.'), 1)); //Get extension
				$image_name = str_replace(' ', '_', $data['sekolah']) . '.' . $ext; //New image name
				$try = move_uploaded_file($_FILES['logo']['tmp_name'], $path.$image_name); // Uploading
				if(!$try) { echo 'Gagal mengupload foto!'; exit; }
				$data['logo'] = $image_name;
			}
			$try = $this->Update_model->getUpdate('statis', 'app_id', '1', $data);
			if( !$try ) { echo 'Gagal merubah data!'; exit; }
			echo 'Data berhasil diubah!';
			exit;
		}
	}
}