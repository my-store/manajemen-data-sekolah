<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
   public function __construct()
   {
      parent::__construct();
      $this->load->model('Read_model');
   }
   
   public function index()
   {
      $data = [
         'title' => 'Homepage',
         'guru' => $this->Read_model->getAll('guru'),
         'kegiatan' => $this->Read_model->getAll('kegiatan'),
         'fasilitas' => $this->Read_model->getAll('fasilitas'),
         'visi' => $this->Read_model->getAll('visi'),
         'misi' => $this->Read_model->getAll('misi'),
         'ruang_info' => $this->Read_model->getAll('ruang_info')
      ];
      $this->load->view('templates/header',$data);
      $this->load->view('home/index');
      $this->load->view('templates/footer');
   }
}