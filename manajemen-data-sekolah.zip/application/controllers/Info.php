<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Info extends CI_Controller
{
   public function __construct()
   {
		parent::__construct();
		if( !isset($this->session->admin_log) )
		{
			redirect( base_url() );
			exit;
		}
      $this->load->model('Read_model');
      $this->load->model('Create_model');
      $this->load->model('Delete_model');
      $this->load->model('Update_model');
	}

	public function getField()
	{
		$row = $this->Read_model->getAll('ruang_info');
		echo count($row);
	}

	public function getData()
	{
		$data['ruanginfo'] = $this->Read_model->getAll('ruang_info');
		echo '
		<h4 class="master-bottom-title">
			<strong class="info">Info</strong>
			<strong class="ket-info">Keterangan</strong>
		</h4>
		<div class="bottom-table">
		';

		$no = 1;

		foreach($data['ruanginfo'] as $ruanginfo)
		{
			echo '
				<h5 onclick="getAct(`Info`,`'.$ruanginfo->id_info.'`,`'.$ruanginfo->info.'`)">'. $no++ .'.
					<strong class="info">'. $ruanginfo->info .'</strong>
					<strong class="ket-info">'. $ruanginfo->keterangan .'</strong>
				</h5>
			';
		}

		if( count($data['ruanginfo']) < 1 )
			echo '<h5>Tabel Ruang info masih kosong.</h5>';

		echo '</div>';
		exit;
	}

   public function newInfo()
   {
      $data = [
         'info' => htmlspecialchars($_POST['info']),
         'keterangan' => htmlspecialchars($_POST['keterangan'])
      ];

      if(empty(
			$data['info'] && $data['keterangan']
      )) { echo 'Data harus lengkap!'; exit; }

      $try = $this->Create_model->getCreate('ruang_info', $data);
		if(!$try) { echo 'Gagal menambahkan data!'; exit; }
		echo 'Data berhasil ditambahkan!';
		exit;
   }

   public function deleteInfo()
   {
      $try = $this->Delete_model->getDelete('ruang_info', 'id_info', $_GET['id']);
		if(!$try) { echo 'Gagal menghapus data!'; exit; }
		echo 'Data berhasil dihapus!';
		exit;
   }
	
	public function updateInfo()
	{
		$id = $_GET['id'];
		$get = $this->Read_model->getOne('ruang_info', 'id_info', $id);
		$elm = '<h3>Tabel Ruang Info <label>Total data: <strong id="row-field"></strong></label></h3>
			<form method="POST" id="info-form">
				<input type="hidden" name="id_info" value="'.$get->id_info.'">
				<div class="form-group">
					<label>Nama Ruang info</label>
					<input type="text" name="info" value="'.$get->info.'">
					<div class="form-button">
						<button onclick="newData(`info`,`getUpdateInfo`)" type="button">Simpan</button>
						<div class="btn-spacer"></div>
						<button onclick="removeField()" type="button">Batal</button>
					</div>
				</div>
				<div class="form-group">
					<label>Keterangan</label>
					<input type="text" name="keterangan" value="'.$get->keterangan.'">
				</div>
			</form>';
		echo $elm;
		exit;
	}

	public function getUpdateInfo()
	{
      $data = [
         'info' => htmlspecialchars($_POST['info']),
         'keterangan' => htmlspecialchars($_POST['keterangan']),
         'id_info' => htmlspecialchars($_POST['id_info'])
      ];

      if(empty(
			$data['info'] && $data['keterangan']
      )) { echo 'Data harus lengkap!'; exit; }

		$try = $this->Update_model->getUpdate('ruang_info', 'id_info', $data['id_info'], $data);
		
		if(!$try) { echo 'Gagal merubah data!'; exit; }
		echo 'Data berhasil diubah!';
		exit;
	}

	public function getSearch()
	{
		$key = $_GET['key'];
		$data['ruanginfo'] = $this->Read_model->getSearch('ruang_info', 'info', $key);
		$no = 1;

		foreach($data['ruanginfo'] as $ruanginfo)
		{
			echo '
				<h5 onclick="getAct(`Info`,`'.$ruanginfo->id_info.'`,`'.$ruanginfo->info.'`)">'. $no++ .'.
					<strong class="info">'. $ruanginfo->info .'</strong>
					<strong class="ket-info">'. $ruanginfo->keterangan .'</strong>
				</h5>
			';
		}

		if( count($data['ruanginfo']) < 1 )
			echo '<h5>Data tidak ditemukan.</h5>';
		exit;
	}
}