<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{
   public function __construct()
   {
      parent::__construct();
      $this->load->model('Read_model');
   }
   
   public function index()
   {
      $data = [
         'username' => $_GET['username'],
         'password' => $_GET['password']
		];
		$get = $this->Read_model->getOne('tata_usaha', 'username', $data['username']);
		if($get)
		{
			if( $data['password'] === $get->password )
			{
				echo '1';
				$this->session->set_userdata('admin_log', $get->username);
				$msg = '<script>alert("Selamat datang '. $get->username .'!");</script>';
				$this->session->set_flashdata('admin_flash', $msg);
				exit;
			}
			else {
				echo 'Password salah!';
				exit;
			}
		}
		else {
			echo 'Username tidak terdaftar, silahkan hubungi admin!';
			exit;
		}
	}
	
	public function logout()
	{
		unset($this->session->admin_log);
		session_destroy();
		session_unset();
		$_SESSION = [];
		redirect(base_url('tatausaha'));
		exit;
	}
}