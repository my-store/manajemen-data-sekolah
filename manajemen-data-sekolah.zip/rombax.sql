-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Nov 2019 pada 13.31
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.1.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rombax`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasilitas`
--

CREATE TABLE `fasilitas` (
  `id_fasilitas` int(11) NOT NULL,
  `nama_fasilitas` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fasilitas`
--

INSERT INTO `fasilitas` (`id_fasilitas`, `nama_fasilitas`, `keterangan`) VALUES
(1, 'Kelas pemrograman', 'Kami menyediakan beberapa kelas untuk kategori pemrograman.'),
(2, 'Gedung mewah', 'Gedung sekolah kami sangat mewah lho.'),
(3, 'Bebas bolos', 'Log boleh bolos kapan aja di sekolah ini.'),
(4, 'Tidur di jam pelajaran', 'Log boleh tidur pas jam pelajaran di sekolah ini.'),
(5, 'Studio musik', 'Jami menyediakan 5 studio musik yang bisa digunakan untuk latihan.'),
(6, 'Lapangan basket', 'Sekolah kami juga memiliki 3 lapangan basket'),
(7, 'Guru cantik', 'Stok guru cantik kami sangat banyak, jadi tidak ada alasan siswa tidak betah di sekolah ini.'),
(8, 'Lapangan volly', 'Kami meiliki 4 lapangan volly di sebelah timur sekolah.'),
(9, 'Kolam renang', 'Kolam renang yang kami sediakan ada 7, ini digunakan setiap hari kamis.'),
(10, 'Makan gratis', 'Kami menyediakan banyak sekali makanan gratis.'),
(11, 'Kopi gratis', 'Lo bisa ngopi sepuasnya di sekolah ini boy.'),
(12, 'Villa mewah', 'Kami menyediakan villa untuk pelajar yang ingin menginap.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id_guru` int(11) NOT NULL,
  `nama_guru` varchar(255) NOT NULL,
  `tmp_lahir` text NOT NULL,
  `tgl_lahir` varchar(50) NOT NULL,
  `almt_guru` text NOT NULL,
  `pendidikan` varchar(255) NOT NULL,
  `nama_instansi` varchar(255) NOT NULL,
  `mengajar` varchar(255) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `foto_guru` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id_guru`, `nama_guru`, `tmp_lahir`, `tgl_lahir`, `almt_guru`, `pendidikan`, `nama_instansi`, `mengajar`, `no_hp`, `foto_guru`) VALUES
(17, 'Wendy', 'Brebes', '12 Maret 1945', 'Kersana', 'SD', 'Pukrul mania', 'Matematika', '0819xxx', 'Wendy.jpg'),
(18, 'Agnes Monica', 'Brebes', '12 Maret 1950', 'Tegal', 'SMP', 'Alam ghaib', 'B Indonesia', '02196', 'Agnes_Monica.jpg'),
(19, 'Parto', 'Tegal', '11 April 1970', 'Tegal', 'SD', 'OVJ', 'B Inggris', '0819xx', 'Parto.jpg'),
(20, 'Darto', 'Jakarta', '6 Desember 1920', 'Brebes', 'SMA', 'DFC', 'B Mandarin', '0819xxx', 'Darto.jpg'),
(22, 'Aziz gagap', 'Brebes', '12 Mei 1956', 'Jagapura', 'SMA', 'Pukrul family', 'IPS', '0819xxx', 'Aziz_gagap.jpg'),
(23, 'Kiwil', 'Jakarta', '12 Maret 1980', 'Jakarta', 'SD', 'Mbuh kue', 'IPA', '0817xxx', 'Kiwil.jpg'),
(26, 'Andre Taulany', 'Brebes', '12 Februari 1087', 'Jagapura', 'SMA', 'Pukrul mania', 'Matematika', '0819xxx', 'Andre_Taulany.jpg'),
(27, 'Jesica Iskandar', 'Brebes', '1950', 'Jagapura', 'SD', 'Pukrul Mania', 'B Indonesia', '0817xxx', 'Jesica_Iskandar.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kegiatan`
--

CREATE TABLE `kegiatan` (
  `id_kegiatan` int(11) NOT NULL,
  `nama_kegiatan` varchar(255) NOT NULL,
  `tgl_kegiatan` varchar(255) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kegiatan`
--

INSERT INTO `kegiatan` (`id_kegiatan`, `nama_kegiatan`, `tgl_kegiatan`, `waktu`, `keterangan`) VALUES
(2, 'Bersih-bersih WC', '12 Maret 2019', '12 Jam', 'Kami mengadakan kegiatan bersih-bersih WC.'),
(3, 'Bersih-bersih taman', '10 April 2019', '5 Jam', 'Kami mengadakan kegiatan bersih-bersih taman.'),
(4, 'Makan bersama', '4 Maret 2019', '12 Jam', 'Kami mengadakan kegiatan makan bersama.'),
(5, 'Libur panjang', '7 Februari 2019', '7 hari', 'Sekolah kami mulai libur panjang selama 7 hari.'),
(6, 'Tournament', '5 Mei 2019', '5 Jam', 'Sekolah kami mengadakan kegiatan tournament sepak bola antar provinsi di jawa tengah.'),
(7, 'Kerja bakti', '3 Juni 2019', '3 Jam', 'Sekolah kami mengadakan kegiatan kerja bakti.'),
(8, 'Tidur di jalan', '3 Januari', '7 Jam', 'Kami mengadakan kegiatan tidur bersama di tengah jalan raya.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `misi`
--

CREATE TABLE `misi` (
  `id_misi` int(11) NOT NULL,
  `misi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `misi`
--

INSERT INTO `misi` (`id_misi`, `misi`) VALUES
(10, 'Menumbuhkan semangat berprestasi dalam bidang akademis kepada seluruh warga sekolah'),
(11, 'Mengembangkan minat dan bakat siswa serta meningkatkan prestasi nonakademis melalui ekstrakurikuler'),
(12, 'Menumbuhkan kesadaran terhadap pengamalan ajaran agama Islam dalam kehidupan sehari-hari'),
(13, 'Mengembangkan budaya santun dalam bertutur dan sopan dalam berperilaku');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruang_info`
--

CREATE TABLE `ruang_info` (
  `id_info` int(11) NOT NULL,
  `info` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ruang_info`
--

INSERT INTO `ruang_info` (`id_info`, `info`, `keterangan`) VALUES
(1, 'PENTING !!!', '3 orang guru matematika kami mati dicipok banci.'),
(2, 'HARI SENIN SEKOLAH KAMI TUTUP', 'Pada hari Senin mendatang sekolah kami akan tutup sementara, alasannya kenapa, kita tunggu saja episode selanjutnya.. See you guys!');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statis`
--

CREATE TABLE `statis` (
  `app_id` int(11) NOT NULL,
  `sekolah` text NOT NULL,
  `alamat` text NOT NULL,
  `logo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `statis`
--

INSERT INTO `statis` (`app_id`, `sekolah`, `alamat`, `logo`) VALUES
(1, 'SDN Jagapura 02', 'Desa Jagapura kec Kersana kab Brebes Jawa tengah 52264', 'SDN_Jagapura_02.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tata_usaha`
--

CREATE TABLE `tata_usaha` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tata_usaha`
--

INSERT INTO `tata_usaha` (`id`, `username`, `password`) VALUES
(1, 'izzat', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `visi`
--

CREATE TABLE `visi` (
  `id_visi` int(11) NOT NULL,
  `visi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `visi`
--

INSERT INTO `visi` (`id_visi`, `visi`) VALUES
(1, 'Berakhlak mulia seperti akhlak Rasulullah saw'),
(2, 'Sopan dan santun dalam berucap dan berbuat'),
(3, 'Berkesadaran spiritual yang kokoh'),
(4, 'Memiliki kepribadian yang terpuji dalam kehidupan bermasyarakat'),
(5, 'Berprestasi akademik secara benar');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `fasilitas`
--
ALTER TABLE `fasilitas`
  ADD PRIMARY KEY (`id_fasilitas`);

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indeks untuk tabel `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id_kegiatan`);

--
-- Indeks untuk tabel `misi`
--
ALTER TABLE `misi`
  ADD PRIMARY KEY (`id_misi`);

--
-- Indeks untuk tabel `ruang_info`
--
ALTER TABLE `ruang_info`
  ADD PRIMARY KEY (`id_info`);

--
-- Indeks untuk tabel `statis`
--
ALTER TABLE `statis`
  ADD PRIMARY KEY (`app_id`);

--
-- Indeks untuk tabel `tata_usaha`
--
ALTER TABLE `tata_usaha`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `visi`
--
ALTER TABLE `visi`
  ADD PRIMARY KEY (`id_visi`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `fasilitas`
--
ALTER TABLE `fasilitas`
  MODIFY `id_fasilitas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id_guru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT untuk tabel `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id_kegiatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `misi`
--
ALTER TABLE `misi`
  MODIFY `id_misi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `ruang_info`
--
ALTER TABLE `ruang_info`
  MODIFY `id_info` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `statis`
--
ALTER TABLE `statis`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tata_usaha`
--
ALTER TABLE `tata_usaha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `visi`
--
ALTER TABLE `visi`
  MODIFY `id_visi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
