

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let tatausahaBtn = $(".tatausaha-btn");
	tatausahaBtn.click(()=>
	{
		let row = getRow('tatausaha');
		let newElm = '<h3>Tabel Tata Usaha <label>Total data: <strong id="row-field">'+ row +'</strong></label></h3>'+
			'<form method="POST" id="tatausaha-form">'+
				'<div class="form-group">'+
					'<label>Username</label>'+
					'<input type="text" name="username">'+
					'<div class="form-button">'+
					'<button onclick="newData(`tatausaha`,`newTatausaha`)" type="button">Simpan</button>'+
					'<div class="btn-spacer"></div>'+
					'<button onclick="removeField()" type="button">Batal</button>'+
					'</div>'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Password</label>'+
					'<input type="text" name="password">'+
				'</div>'+
			'</form>'
		;
		insertForm(newElm);
		getData('tatausaha');
		$(".master-ctn").addClass("master-ctn-active");
	});
});


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/