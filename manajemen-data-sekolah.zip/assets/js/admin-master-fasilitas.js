

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let fasilitasBtn = $(".fasilitas-btn");
	fasilitasBtn.click(()=>
	{
		let row = getRow('fasilitas');
		let newElm = '<h3>Tabel Fasilitas <label>Total data: <strong id="row-field">'+ row +'</strong></label></h3>'+
			'<form method="POST" id="fasilitas-form">'+
				'<div class="form-group">'+
					'<label>Nama Fasilitas</label>'+
					'<input type="text" name="nama_fasilitas">'+
					'<div class="form-button">'+
					'<button onclick="newData(`fasilitas`,`newFasilitas`)" type="button">Simpan</button>'+
					'<div class="btn-spacer"></div>'+
					'<button onclick="removeField()" type="button">Batal</button>'+
					'</div>'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Keterangan</label>'+
					'<input type="text" name="keterangan">'+
				'</div>'+
			'</form>'
		;
		insertForm(newElm);
		getData('fasilitas');
		$(".master-ctn").addClass("master-ctn-active");
	});
});


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/