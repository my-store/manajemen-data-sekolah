

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


// Insert and Update Data
function newData( id, func )
{
	let form = $('#' + id + '-form')[0];
	let form_data = new FormData( form );
	
	$.ajax(
		{
			type: "POST",
			enctype: 'multipart/form-data',
			url: $("#base_url").val() + id + "/" + func,
			data: form_data,
			processData: false,
			contentType: false,
			cache: false,
			timeout: 600000,
			success: function(response = null)
			{
				if(id !== "app")
				{
					removeField();
				}
				else if(id === "app")
				{
					$("#app-form input").val('');
				}
				getLogo();
				getRow(id);
				getData( id, 'scroll' );
				alert(response);
				return;
			}
	});
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/