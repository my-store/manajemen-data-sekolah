

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let ruanginfoBtn = $(".ruanginfo-btn");
	ruanginfoBtn.click(()=>
	{
		let row = getRow('info');
		let newElm = '<h3>Tabel Ruang Info <label>Total data: <strong id="row-field">'+ row +'</strong></label></h3>'+
			'<form method="POST" id="info-form">'+
				'<div class="form-group">'+
					'<label>Nama info</label>'+
					'<input type="text" name="info">'+
					'<div class="form-button">'+
						'<button onclick="newData(`info`,`newInfo`)" type="button">Simpan</button>'+
						'<div class="btn-spacer"></div>'+
						'<button onclick="removeField()" type="button">Batal</button>'+
					'</div>'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Keterangan</label>'+
					'<input type="text" name="keterangan">'+
				'</div>'+
			'</form>'
		;
		insertForm(newElm);
		getData('info');
		$(".master-ctn").addClass("master-ctn-active");
	});
});


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/