

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


function getDelete()
{
	let id = $("#action-data").val();
	let ctrl = $("#action-data").attr("title");
	if( confirm("Yakin mau dihapus?") == true )
	{
		$.get(
			$("#base_url").val()+ctrl+'/delete'+ctrl,
			{ id: id }, (response = null)=>
			{
				getRow(ctrl);
				removeAction();
				getData( ctrl, 'scroll' );
				alert(response);
				return;
			}
		);
	}
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/