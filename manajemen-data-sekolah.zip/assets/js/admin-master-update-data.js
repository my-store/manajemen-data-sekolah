

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/

function getUpdate()
{
	// Table = Controller
	let id = $("#action-data").val();
	let table = $("#action-data").attr("title");
	let form = $(".master-top > form").attr("id");
	let row = null;
	let elm = $("#row-field");
	if(form === "tatausaha-form")
	{
		row = 'tatausaha';
	}
	if(form === "fasilitas-form")
	{
		row = 'fasilitas';
	}
	if(form === "guru-form")
	{
		row = 'guru';
	}
	if(form === "kegiatan-form")
	{
		row = 'kegiatan';
	}
	if(form === "info-form")
	{
		row = 'info';
	}
	$.get(
		$("#base_url").val()+table+"/update"+table,
		{ id: id }, (response)=>
		{
			// Result
			insertForm(response);
			removeAction();
			elm.html(getRow(row));
		}
	);
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/