

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let modal = $(".modalbox");
	let closeModal = $(".close-modal");
	let loginBtn = $(".login-btn");
	let fasilitas = $(".fasilitasBtn");
	let profileguru = $(".profile-guruBtn");
	let fasilitasCtn = $(".fasilitas-content");
	let fasilitasBox = $(".fasilitas-box");
	let profileguruCtn = $(".profileguru-content");
	let profileguruBox = $(".profileguru-box");
	let getLogBtn = $("#getLog-btn");

	loginBtn.click(()=>
	{
		modal.addClass("modalbox-active");
	});
	closeModal.click(()=>
	{
		modal.removeClass("modalbox-active");
	});

	fasilitas.click(()=>
	{
		fasilitas.toggleClass("fasilitas-profile-active");
		fasilitasCtn.toggleClass("content-active");
		fasilitasBox.toggleClass("fasilitas-box-active");
		profileguruCtn.removeClass("content-active");
		profileguru.removeClass("fasilitas-profile-active");
		profileguruBox.removeClass("profileguru-box-active");
		removeBigPhoto('guru');
		removeBigPhoto('fasilitas');
	});

	profileguru.click(()=>
	{
		profileguru.toggleClass("fasilitas-profile-active");
		profileguruCtn.toggleClass("content-active");
		profileguruBox.toggleClass("profileguru-box-active");
		fasilitasCtn.removeClass("content-active");
		fasilitas.removeClass("fasilitas-profile-active");
		fasilitasBox.removeClass("fasilitas-box-active");
		removeBigPhoto('fasilitas');
		removeBigPhoto('guru');
	});

	getLogBtn.click(()=>
	{
		let usr = $("#username").val();
		let pass = $("#password").val();
		let url = $("#base_url").val();
		
		if(
			usr != ''
			&&
			pass != ''
		) {
			$.get(
				url + "auth",
				{
					username: usr,
					password: pass
				},
				(response)=>
				{
					if( response === '1' )
					{ window.location=url+"tatausaha"; }
					else { alert(response); }
				}
			);
		} else {
			alert("Data wajib di isi!");
		}
	});

	getLogo();
	getData("app");	// Get school name and address

   clockUpdate();  // Updating clock
   setInterval(clockUpdate, 1000);  // Set delay for Updating clock
   // Pushing clock on the #date element
   let hari = $("#date");
   hari.text( getDay() );
   
});


// Push text function for the .hari element
function getDay()
{
   let x = new Date();
   let rbx = x.toLocaleDateString('id', {weekday:'long'});
   return rbx + ', ' + x.getDate() + ' ' + x.toLocaleDateString('id', {month:'long'}) + ' ' + x.getFullYear();
}

// Clock update function
function clockUpdate() {
  var date = new Date();
  $('#clock').css({'color': '#fff', 'text-shadow': '0 0 9px rgb(0, 94, 117)'});
  function addZero(x) {
    if (x < 10) {
      return x = '0' + x;
    } else {
      return x;
    }
  }

  var h = addZero( date.getHours() );
  var m = addZero( date.getMinutes() );
  var s = addZero( date.getSeconds() );

  $('#clock').html(h + ':' + m + '<div id="seconds">' + s +'</div>')
}

function changeBG(id,bg,nm=null,hp=null,tmp=null,almt=null,inst=null,pnd=null,ngjr=null)
{
	let bigPhoto = $(".big-photo-"+id);
	if( id="guru" ) bigPhoto.html("<h5><label class='nama-guru'>"+nm+"</label><label>Telp: "+hp+"</label><label>Tmp Lahir: "+tmp+"</label><label>Alamat: "+almt+"</label><label>Instansi: "+inst+"</label><label>Pendidikan: "+pnd+"</label><label>Mengajar: "+ngjr+"</label></h5>");
	bigPhoto.css("background-image","url("+$("#base_url").val()+"/assets/img/foto_guru/"+bg+")");
	bigPhoto.addClass("big-photo-active");
}

function removeBigPhoto( id )
{
	$(".big-photo-"+id).removeClass("big-photo-active");
}

function getData( id )
{
	$.get(
		$("#base_url").val() + id + "/getData",
		{}, (response)=>
		{
			$(".nav-header").html(response);
			return;
		}
	);
}

function getLogo()
{
	$.get(
		$("#base_url").val() + "app/getLogo",
		{}, (response)=>
		{
			if( response === "0" ) alert("Data tidak ditemukan!");
			else $(".nav-logo").html(response);
			return;
		}
	);
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/

