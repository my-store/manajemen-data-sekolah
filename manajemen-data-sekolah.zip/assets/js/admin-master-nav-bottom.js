

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let homeBtn = $(".home-btn");
	let aboutBtn = $(".about-btn");
	let homeCtn = $(".nav-home-ctn");
	let aboutCtn = $(".nav-about-ctn");
	let homeClose = $(".home-close");
	let aboutClose = $(".about-close");

	homeBtn.click(()=>
	{
		// 
		removeDashboard();
		homeCtn.addClass("nav-home-ctn-active");
	});

	aboutBtn.click(()=>
	{
		// 
		removeDashboard();
		aboutCtn.addClass("nav-about-ctn-active");
	});

	homeClose.click(()=>
	{
		removeNavCtn(homeCtn, "nav-home-ctn-active");
	});

	aboutClose.click(()=>
	{
		removeNavCtn(aboutCtn, "nav-about-ctn-active");
	});
});

function removeNavCtn(target=null, cls=null)
{
	target.removeClass(cls);
	$(".nav-bottom-ctn").removeClass("nav-bottom-ctn-active");
	$(".dashboard").removeClass("dashboard-active");
}

function removeDashboard()
{
	$(".nav-bottom-ctn").addClass("nav-bottom-ctn-active");
	$(".dashboard").addClass("dashboard-active");
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/

