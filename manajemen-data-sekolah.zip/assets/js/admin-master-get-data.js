

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


function getData( id, scroll=null )
{
	$.get(
		$("#base_url").val() + id + "/getData",
		{}, (response)=>
		{
			if(id !== "app")
			{
				$("#master > .master-bottom").html(response);
				if(scroll !== null) scrollDown();
			}
			else if(id === "app")
			{
				$(".nav-header").html(response);
			}
			getLogo();
			return;
		}
	);
}

function getLogo()
{
	$.get(
		$("#base_url").val() + "app/getLogo",
		{}, (response)=>
		{
			if(response !== '0') $(".nav-logo").html(response);
			else if( response === "0" ) alert("Data tidak ditemukan!");
			return;
		}
	);
}

function getSearch( id, key=null )
{
	$.get(
		$("#base_url").val() + id + "/getSearch",
		{key: key}, (response)=>
		{
			$(".bottom-table").html(response);
			return;
		}
	);
}

function getRow( id )
{
	$.get(
		$("#base_url").val() + id + "/getField",
		{}, (response)=>
		{
			$("#row-field").html(response);
			return;
		}
	);
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/