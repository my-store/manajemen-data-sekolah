

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let guruBtn = $(".guru-btn");
	guruBtn.click(()=>
	{
		let row = getRow('guru');
		let newElm = '<h3>Tabel Guru <label>Total data: <strong id="row-field">'+ row +'</strong></label></h3>'+
			'<form method="POST" id="guru-form" enctype="multipart/form-data">'+
				'<div class="form-group">'+
					'<label>Nama guru</label>'+
					'<input name="nama_guru" type="text">'+
					'<label>Nama Instansi</label>'+
					'<input name="nama_instansi" type="text">'+
					'<label>Foto guru</label>'+
					'<input title="Unggah Foto" id="foto-guru" name="foto_guru" type="file">'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Nomor telp</label>'+
					'<input name="no_hp" type="text">'+
					'<label>Pendidikan</label>'+
					'<input name="pendidikan" type="text">'+
					'<div class="form-button">'+
						'<button onclick="newData(`guru`,`newGuru`)" type="button">Simpan</button>'+
						'<div class="btn-spacer"></div>'+
						'<button onclick="removeField()" type="button">Batal</button>'+
					'</div>'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Tempat kelahiran</label>'+
					'<input name="tmp_lahir" type="text">'+
					'<label>Mengajar</label>'+
					'<input name="mengajar" type="text">'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Alamat</label>'+
					'<input name="almt_guru" type="text">'+
					'<label>Tgl lahir</label>'+
					'<input name="tgl_lahir" type="text">'+
				'</div>'+
			'</form>'
		;
		insertForm(newElm);
		getData('guru');
		$(".master-ctn").addClass("master-ctn-active");
	});
});


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/