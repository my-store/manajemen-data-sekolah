

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let masterCtn = $(".master-ctn");
	let closeMaster = $(".close-master");
	let logoutBtn = $(".logout-btn");
	let searchBtn = $(".search-master");
	let searchBox = $(".search-field");
	let searchClose = $(".search-close");

	closeMaster.click(()=>	// Close master box
	{
		masterCtn.removeClass("master-ctn-active");
		removeField();
	});

	logoutBtn.click(()=>
	{
		if( confirm("Temenan pan metu boss?") == true )
			window.location = $("#base_url").val() + "auth/logout";
	});

	searchBtn.click(()=>
	{
		searchBox.addClass("search-field-active");
		searchBtn.addClass("search-master-active");
		searchClose.addClass("search-close-active");
	});

	searchClose.click(()=>
	{
		searchBox.removeClass("search-field-active");
		searchBtn.removeClass("search-master-active");
		searchClose.removeClass("search-close-active");
	});

	searchBox.keyup(()=>
	{
		let form = $("#master > .master-top > form").attr("id");
		if(form == "tatausaha-form") getSearch('tatausaha', $(".search-field").val());
		if(form == "fasilitas-form") getSearch('fasilitas', $(".search-field").val());
		if(form == "guru-form") getSearch('guru', $(".search-field").val());
		if(form == "kegiatan-form") getSearch('kegiatan', $(".search-field").val());
		if(form == "info-form") getSearch('info', $(".search-field").val());
	});

	getLogo();
	getData("app");	// Get school name and address
});

function insertForm( comp )
{
	$("#master > .master-top").html( comp );
}

function scrollDown()
{
	$(".bottom-table").animate({
		scrollTop: $(".bottom-table").prop("scrollHeight")
	}, 1000);
}

function removeField()
{
	$(".master-top form input").val('');
	let form = $(".master-top form");
	if( form.attr("id") === "tatausaha-form" ) 
	{
		$(".master-top form button:first").attr("onclick","newData(`tatausaha`,`newTatausaha`)");
	}
	if( form.attr("id") === "fasilitas-form" ) 
	{
		$(".master-top form button:first").attr("onclick","newData(`fasilitas`,`newFasilitas`)");
	}
	if( form.attr("id") === "guru-form" ) 
	{
		$(".master-top form button:first").attr("onclick","newData(`guru`,`newGuru`)");
	}
	if( form.attr("id") === "kegiatan-form" ) 
	{
		$(".master-top form button:first").attr("onclick","newData(`kegiatan`,`newKegiatan`)");
	}
	if( form.attr("id") === "info-form" ) 
	{
		$(".master-top form button:first").attr("onclick","newData(`info`,`newInfo`)");
	}
}




/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/
