

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


$(document).ready(()=>
{
	let kegiatanBtn = $(".kegiatan-btn");
	kegiatanBtn.click(()=>
	{
		let row = getRow('kegiatan');
		let newElm = '<h3>Tabel Kegiatan <label>Total data: <strong id="row-field">'+ row +'</strong></label></h3>'+
			'<form method="POST" id="kegiatan-form">'+
				'<div class="form-group">'+
					'<label>Nama Kegiatan</label>'+
					'<input type="text" name="nama_kegiatan">'+
					'<label>Waktu Kegiatan</label>'+
					'<input type="text" name="waktu">'+
					'<div class="form-button">'+
					'<button onclick="newData(`kegiatan`,`newKegiatan`)" type="button">Simpan</button>'+
					'<div class="btn-spacer"></div>'+
					'<button onclick="removeField()" type="button">Batal</button>'+
					'</div>'+
				'</div>'+
				'<div class="form-group">'+
					'<label>Tanggal Kegiatan</label>'+
					'<input type="text" name="tgl_kegiatan">'+
					'<label>Keterangan</label>'+
					'<input type="text" name="keterangan">'+
				'</div>'+
			'</form>'
		;
		insertForm(newElm);
		getData('kegiatan');
		$(".master-ctn").addClass("master-ctn-active");
	});
});


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/