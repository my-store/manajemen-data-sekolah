

/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/


function getAct( ctrl, id, name )
{
	let data = '<input title="'+ctrl+'" id="action-data" type="hidden" value="'+id+'">';
	let hiddenID = $("#hidden-action-id");
	hiddenID.html(data);
	let actionTitle = $("#action-title");
	actionTitle.html( "Nama: "+name+"<br>Kategori: "+ctrl );
	let actionCtn = $(".action-content");
	actionCtn.addClass("action-content-active");
}

function removeAction()
{
	$(".action-content").removeClass("action-content-active");
}


/*/ =====<>  RBX Family  <>===== /*/
/*/ < izzatalharist@gmail.com > /*/